export default {
  spacing: factor => `${0.16 * factor}rem`
}
